import 'dart:ui' show FontFeature;
import 'package:flutter/material.dart';

void main() => runApp(const VideoClipManagerDemo());

class UiColors {
  static const bg = Color(0xFF171A20);
  static const sidebar = Color(0xFF1E222B);
  static const surface = Color(0xFF252A34);
  static const elevated = Color(0xFF303644);
  static const border = Color(0xFF3B414E);
  static const primary = Color(0xFF8B7CF6);
  static const text = Color(0xFFF1F2F6);
  static const muted = Color(0xFFA5ADBB);
  static const good = Color(0xFF78D9B8);
  static const end = Color(0xFFF4B36B);
}

ThemeData buildTheme() {
  final scheme = ColorScheme.fromSeed(seedColor: UiColors.primary, brightness: Brightness.dark)
      .copyWith(primary: UiColors.primary, surface: UiColors.surface, onSurface: UiColors.text);
  return ThemeData(
    useMaterial3: true,
    brightness: Brightness.dark,
    scaffoldBackgroundColor: UiColors.bg,
    colorScheme: scheme,
    appBarTheme: const AppBarTheme(backgroundColor: UiColors.bg, foregroundColor: UiColors.text),
    cardTheme: CardThemeData(color: UiColors.surface, margin: EdgeInsets.zero,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
    inputDecorationTheme: InputDecorationTheme(
      filled: true, fillColor: UiColors.elevated,
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide.none),
      contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12)),
    filledButtonTheme: FilledButtonThemeData(style: FilledButton.styleFrom(
      backgroundColor: UiColors.primary,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(9)))),
    dividerColor: UiColors.border,
  );
}

class DemoClip {
  DemoClip(this.id, this.name, this.source, this.total, this.start, this.end,
      {this.rating = 0, this.favorite = false, this.tags = const []});
  final int id;
  String name;
  final String source;
  final Duration total;
  Duration start;
  Duration end;
  int rating;
  bool favorite;
  List<String> tags;
  Duration get duration => end - start;
}

String timecode(Duration time, {bool ms = false}) {
  final h = time.inHours;
  final m = time.inMinutes.remainder(60).toString().padLeft(2, '0');
  final s = time.inSeconds.remainder(60).toString().padLeft(2, '0');
  final prefix = h > 0 ? '${h.toString().padLeft(2, '0')}:' : '';
  final millis = ms ? '.${time.inMilliseconds.remainder(1000).toString().padLeft(3, '0')}' : '';
  return '$prefix$m:$s$millis';
}

class VideoClipManagerDemo extends StatefulWidget {
  const VideoClipManagerDemo({super.key});
  @override
  State<VideoClipManagerDemo> createState() => _VideoClipManagerDemoState();
}

class _VideoClipManagerDemoState extends State<VideoClipManagerDemo> {
  final clips = <DemoClip>[
    DemoClip(1, '精选片段 01', 'source_a.mp4', const Duration(minutes: 2), const Duration(seconds: 9), const Duration(minutes: 1, seconds: 30), favorite: true, rating: 4, tags: ['精选']),
    DemoClip(2, '旅行记录', 'source_b.mp4', const Duration(minutes: 9), Duration.zero, const Duration(minutes: 5, seconds: 33), rating: 3, tags: ['旅行']),
    DemoClip(3, '短片段', 'source_c.avi', const Duration(minutes: 1), const Duration(seconds: 4), const Duration(seconds: 59), rating: 5),
    DemoClip(4, '收藏片段', 'source_d.mp4', const Duration(minutes: 8), const Duration(seconds: 3), const Duration(minutes: 6, seconds: 9), favorite: true),
    DemoClip(5, '户外剪辑', 'source_e.mp4', const Duration(minutes: 4), const Duration(seconds: 15), const Duration(minutes: 2, seconds: 28), tags: ['户外']),
    DemoClip(6, '精彩瞬间', 'source_f.mp4', const Duration(minutes: 3), Duration.zero, const Duration(seconds: 48), rating: 4),
  ];
  final playlistIds = <int>[3, 4, 1];
  int page = 0;
  DemoClip? editing;
  bool favoritesOnly = false;
  String query = '';
  bool listView = false;
  String sort = '最近添加';

  void edit(DemoClip clip) => setState(() { editing = clip; page = 3; });
  void notify(String message) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Video Clip Manager — Dark UI',
      debugShowCheckedModeBanner: false,
      theme: buildTheme(),
      home: LayoutBuilder(builder: (context, viewport) {
        final narrow = viewport.maxWidth < 1050;
        final railWidth = narrow ? 76.0 : 208.0;
        return Scaffold(body: Row(children: [
          Container(width: railWidth, color: UiColors.sidebar,
            child: Column(children: [
              Padding(padding: const EdgeInsets.fromLTRB(20, 24, 12, 28),
                child: Row(children: [const Icon(Icons.movie_filter_outlined, color: UiColors.primary),
                  if (!narrow) const Padding(padding: EdgeInsets.only(left: 12), child: Text('VIDEO CLIP', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1.1)))])),
              navItem(0, Icons.content_cut, '片段库', narrow),
              navItem(1, Icons.video_library_outlined, '原始视频', narrow),
              navItem(2, Icons.playlist_play_rounded, '播放列表', narrow),
              const Spacer(),
              navItem(-1, Icons.settings_outlined, '设置', narrow),
              const SizedBox(height: 18),
            ])),
          Expanded(child: Column(children: [
            Container(height: 60, padding: const EdgeInsets.symmetric(horizontal: 24),
              decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: UiColors.border))),
              child: Row(children: [Text(page == 3 ? '片段编辑器' : ['片段库', '原始视频', '播放列表'][page],
                  style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w600)),
                const Spacer(), const Icon(Icons.storage_outlined, size: 18, color: UiColors.muted),
                const SizedBox(width: 8), const Text('本地媒体库', style: TextStyle(color: UiColors.muted, fontSize: 12)),
                const SizedBox(width: 20), IconButton(tooltip: '关于原型', onPressed: () => notify('独立 UI 演示：不读写实际 JSON / 视频文件'), icon: const Icon(Icons.info_outline))])),
            Expanded(child: switch (page) {
              0 => library(),
              1 => sources(),
              2 => playlist(),
              _ => editor(),
            }),
          ])),
        ]));
      }),
    );
  }

  Widget navItem(int value, IconData icon, String title, bool compact) {
    final active = page == value || (value == 0 && page == 3);
    return Padding(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      child: Tooltip(message: title, child: Material(color: active ? UiColors.primary.withValues(alpha: .22) : Colors.transparent,
        borderRadius: BorderRadius.circular(10),
        child: InkWell(borderRadius: BorderRadius.circular(10), onTap: () {
          if (value < 0) { notify('将此入口连接到现有 SettingsScreen'); return; }
          setState(() => page = value);
        }, child: Padding(padding: const EdgeInsets.all(13), child: Row(
          mainAxisAlignment: compact ? MainAxisAlignment.center : MainAxisAlignment.start,
          children: [Icon(icon, color: active ? const Color(0xFFC9BFFF) : UiColors.muted, size: 21),
          if (!compact) ...[const SizedBox(width: 14), Text(title, style: TextStyle(color: active ? UiColors.text : UiColors.muted, fontWeight: active ? FontWeight.w600 : FontWeight.w400))]]))))));
  }

  Widget library() {
    var visible = clips.where((c) => (!favoritesOnly || c.favorite) &&
      ('${c.name} ${c.source} ${c.tags.join(' ')}'.toLowerCase().contains(query.toLowerCase()))).toList();
    if (sort == '时长最长') visible.sort((a, b) => b.duration.compareTo(a.duration));
    if (sort == '评分最高') visible.sort((a, b) => b.rating.compareTo(a.rating));
    if (sort == '最近添加') visible.sort((a, b) => b.id.compareTo(a.id));
    return Padding(padding: const EdgeInsets.all(24), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [const Text('我的片段', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w700)),
        const SizedBox(width: 12), Text('${visible.length} / ${clips.length}', style: const TextStyle(color: UiColors.muted)),
        const Spacer(), FilledButton.icon(onPressed: () => edit(clips.first), icon: const Icon(Icons.add), label: const Text('创建片段'))]),
      const SizedBox(height: 20),
      Row(children: [Expanded(child: TextField(onChanged: (s) => setState(() => query = s),
        decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: '搜索片段名称、标签或文件名…'))),
        const SizedBox(width: 12), DropdownButton<String>(value: sort, underline: const SizedBox.shrink(),
          items: ['最近添加', '评分最高', '时长最长'].map((s) => DropdownMenuItem(value: s, child: Text(s))).toList(),
          onChanged: (s) => setState(() => sort = s!)),
        const SizedBox(width: 12), IconButton.filledTonal(tooltip: '网格视图',
          onPressed: () => setState(() => listView = false), icon: const Icon(Icons.grid_view)),
        IconButton.filledTonal(tooltip: '列表视图', onPressed: () => setState(() => listView = true), icon: const Icon(Icons.view_list))]),
      const SizedBox(height: 12),
      Row(children: [FilterChip(label: const Text('全部'), selected: !favoritesOnly,
        onSelected: (_) => setState(() => favoritesOnly = false)),
        const SizedBox(width: 8), FilterChip(label: const Text('仅收藏'), selected: favoritesOnly,
        onSelected: (_) => setState(() => favoritesOnly = true)),
        const Spacer(), Text('共 ${visible.length} 个结果', style: const TextStyle(color: UiColors.muted))]),
      const SizedBox(height: 14),
      Expanded(child: visible.isEmpty ? const Center(child: Text('没有匹配的片段', style: TextStyle(color: UiColors.muted))) :
        LayoutBuilder(builder: (context, constraints) {
          if (listView) return ListView.separated(itemCount: visible.length, separatorBuilder: (_, _) => const SizedBox(height: 10),
            itemBuilder: (context, index) => clipRow(visible[index]));
          final count = (constraints.maxWidth / 235).floor().clamp(1, 6);
          return GridView.builder(gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: count,
            crossAxisSpacing: 14, mainAxisSpacing: 14, childAspectRatio: 1.22),
            itemCount: visible.length, itemBuilder: (context, i) => clipCard(visible[i]));
        })),
    ]));
  }

  Widget fakeThumbnail(DemoClip clip) {
    const colors = [Color(0xFF384A55), Color(0xFF454059), Color(0xFF454A40), Color(0xFF53404B), Color(0xFF36505A), Color(0xFF4B4B64)];
    return Container(color: colors[clip.id % colors.length], alignment: Alignment.center,
      child: const Icon(Icons.play_circle_outline, color: Color(0xFFB5B7CB), size: 44));
  }

  Widget clipCard(DemoClip clip) => Card(clipBehavior: Clip.antiAlias, child: InkWell(onDoubleTap: () => notify('播放入口：连接现有 ClipPlayerScreen'), onTap: () => edit(clip),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Expanded(child: Stack(fit: StackFit.expand, children: [fakeThumbnail(clip),
        Positioned(right: 8, bottom: 8, child: Container(padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 4),
          decoration: BoxDecoration(color: Colors.black87, borderRadius: BorderRadius.circular(5)),
          child: Text(timecode(clip.duration), style: const TextStyle(fontSize: 11, fontFeatures: [FontFeature.tabularFigures()]))))])),
      Padding(padding: const EdgeInsets.fromLTRB(12, 10, 6, 6), child: Row(children: [
        Expanded(child: Text(clip.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w600))),
        IconButton(visualDensity: VisualDensity.compact, iconSize: 18, tooltip: '收藏',
          onPressed: () => setState(() => clip.favorite = !clip.favorite),
          icon: Icon(clip.favorite ? Icons.favorite : Icons.favorite_border, color: clip.favorite ? const Color(0xFFF1778A) : UiColors.muted))])),
      Padding(padding: const EdgeInsets.fromLTRB(12, 0, 8, 10), child: Row(children: [
        ...List.generate(5, (i) => InkWell(onTap: () => setState(() => clip.rating = clip.rating == i + 1 ? 0 : i + 1),
          child: Icon(i < clip.rating ? Icons.star : Icons.star_border, size: 15, color: i < clip.rating ? const Color(0xFFFFC65C) : UiColors.muted))),
        const Spacer(), IconButton(visualDensity: VisualDensity.compact, iconSize: 17, tooltip: '编辑片段', onPressed: () => edit(clip), icon: const Icon(Icons.edit_outlined))]))
    ])));

  Widget clipRow(DemoClip clip) => Card(child: ListTile(leading: SizedBox(width: 94, height: 54, child: fakeThumbnail(clip)),
    title: Text(clip.name), subtitle: Text('${clip.source} · ${timecode(clip.duration)}'),
    trailing: Wrap(crossAxisAlignment: WrapCrossAlignment.center, children: [
      IconButton(onPressed: () => setState(() => clip.favorite = !clip.favorite),
        icon: Icon(clip.favorite ? Icons.favorite : Icons.favorite_border, color: clip.favorite ? const Color(0xFFF1778A) : UiColors.muted)),
      IconButton(onPressed: () => edit(clip), icon: const Icon(Icons.edit_outlined))]), onTap: () => edit(clip)));

  Widget sources() => Padding(padding: const EdgeInsets.all(24), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    const Text('原始视频', style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold)), const SizedBox(height: 8),
    const Text('这里展示已导入的源视频。示例使用片段所引用的文件名；实际接入现有 Original Videos 页面。', style: TextStyle(color: UiColors.muted)),
    const SizedBox(height: 20), Expanded(child: ListView(children: clips.map((c) => Card(child: ListTile(
      leading: const Icon(Icons.movie_outlined, color: UiColors.primary), title: Text(c.source),
      subtitle: Text('源时长 ${timecode(c.total)}'), trailing: const Icon(Icons.chevron_right), onTap: () => edit(c)))).toList()))]));

  Widget editor() {
    final c = editing ?? clips.first;
    final startSeconds = c.start.inMilliseconds / 1000.0;
    final endSeconds = c.end.inMilliseconds / 1000.0;
    final max = c.total.inMilliseconds / 1000.0;
    return Padding(padding: const EdgeInsets.all(24), child: Column(children: [
      Row(children: [IconButton(onPressed: () => setState(() => page = 0), icon: const Icon(Icons.arrow_back)),
        const SizedBox(width: 8), Expanded(child: Text('编辑片段 · ${c.source}', overflow: TextOverflow.ellipsis,
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600))),
        FilledButton.icon(onPressed: () { setState(() => page = 0); notify('演示状态已更新；接入项目时请调用现有 AppState 保存方法'); },
          icon: const Icon(Icons.save_outlined), label: const Text('保存片段'))]),
      const SizedBox(height: 18),
      Expanded(child: LayoutBuilder(builder: (context, cons) {
        final vertical = cons.maxWidth < 780;
        final video = Column(children: [
          AspectRatio(aspectRatio: 16 / 9, child: Container(decoration: BoxDecoration(color: Colors.black,
            borderRadius: BorderRadius.circular(12)), child: const Center(child: Icon(Icons.play_circle_outline, size: 72, color: UiColors.muted)))),
          const SizedBox(height: 8), const Row(children: [Icon(Icons.info_outline, size: 16, color: UiColors.muted),
            SizedBox(width: 8), Expanded(child: Text('播放器占位区：接入现有 Media Kit Player / VideoController',
              style: TextStyle(color: UiColors.muted, fontSize: 12)))]),
        ]);
        final details = Container(padding: const EdgeInsets.all(18), decoration: BoxDecoration(color: UiColors.surface, borderRadius: BorderRadius.circular(12)),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('片段信息', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)), const SizedBox(height: 16),
            const Text('片段名称', style: TextStyle(color: UiColors.muted)), const SizedBox(height: 7),
            TextFormField(key: ValueKey('name-${c.id}'), initialValue: c.name, onChanged: (s) => c.name = s),
            const SizedBox(height: 16), const Text('标签（逗号分隔）', style: TextStyle(color: UiColors.muted)),
            const SizedBox(height: 7), TextFormField(key: ValueKey('tags-${c.id}'), initialValue: c.tags.join(', '),
              onChanged: (s) => c.tags = s.split(',').map((s) => s.trim()).where((s) => s.isNotEmpty).toList()),
            const SizedBox(height: 16), const Text('源文件', style: TextStyle(color: UiColors.muted)),
            const SizedBox(height: 7), Text(c.source, overflow: TextOverflow.ellipsis),
          ]));
        return SingleChildScrollView(child: Column(children: [
          if (vertical) ...[video, const SizedBox(height: 16), details] else Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Expanded(flex: 7, child: video), const SizedBox(width: 16), Expanded(flex: 3, child: details)]),
          const SizedBox(height: 20),
          Container(padding: const EdgeInsets.all(18), decoration: BoxDecoration(color: UiColors.surface, borderRadius: BorderRadius.circular(12)),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [const Text('精确片段范围', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
                const Spacer(), Text('源视频 ${timecode(c.total)}', style: const TextStyle(color: UiColors.muted))]),
              const SizedBox(height: 12),
              RangeSlider(values: RangeValues(startSeconds, endSeconds), min: 0, max: max,
                labels: RangeLabels(timecode(c.start, ms: true), timecode(c.end, ms: true)),
                onChanged: (r) => setState(() { c.start = Duration(milliseconds: (r.start * 1000).round());
                  c.end = Duration(milliseconds: (r.end * 1000).round()); })),
              Row(children: [Expanded(child: timeCell('IN', c.start, UiColors.good)),
                const SizedBox(width: 10), Expanded(child: timeCell('OUT', c.end, UiColors.end)),
                const SizedBox(width: 10), Expanded(child: timeCell('DURATION', c.duration, UiColors.primary))]),
              const SizedBox(height: 12), const Text('正式版本：支持 I / O 标记、逐帧调整、可缩放时间轴。此原型的 RangeSlider 为秒级演示；底层存储仍使用毫秒。',
                style: TextStyle(color: UiColors.muted, fontSize: 12)),
            ])),
        ]));
      }))
    ]));
  }

  Widget timeCell(String name, Duration duration, Color color) => Container(padding: const EdgeInsets.all(12),
    decoration: BoxDecoration(color: UiColors.elevated, borderRadius: BorderRadius.circular(9)),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(name, style: const TextStyle(fontSize: 11, color: UiColors.muted)), const SizedBox(height: 5),
      Text(timecode(duration, ms: true), style: TextStyle(color: color, fontWeight: FontWeight.bold, fontFeatures: const [FontFeature.tabularFigures()]))]));

  Widget playlist() {
    final items = playlistIds.map((id) => clips.firstWhere((c) => c.id == id)).toList();
    final totalMs = items.fold<int>(0, (sum, c) => sum + c.duration.inMilliseconds);
    final colors = [const Color(0xFFE27A83), const Color(0xFF8B69BC), const Color(0xFF6ABDB5)];
    return Padding(padding: const EdgeInsets.all(24), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('list1', style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
        Text('播放列表工作台', style: TextStyle(color: UiColors.muted))]),
        const Spacer(), FilledButton.icon(onPressed: () => notify('播放入口：接入现有 PlaylistPlayerScreen'),
          icon: const Icon(Icons.play_arrow), label: const Text('播放列表'))]),
      const SizedBox(height: 22), Container(padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(color: UiColors.surface, borderRadius: BorderRadius.circular(12)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [const Text('时间轴', style: TextStyle(fontWeight: FontWeight.bold)),
            const Spacer(), Text('总时长 ${timecode(Duration(milliseconds: totalMs))}', style: const TextStyle(color: UiColors.muted))]),
          const SizedBox(height: 18), SizedBox(height: 72, child: Row(children: [
            for (var i = 0; i < items.length; i++) Expanded(
              flex: items[i].duration.inMilliseconds.clamp(1, 999999999),
              child: Container(margin: const EdgeInsets.only(right: 3), alignment: Alignment.center,
                decoration: BoxDecoration(color: colors[i % colors.length], borderRadius: BorderRadius.circular(7)),
                child: LayoutBuilder(builder: (_, bounds) => bounds.maxWidth < 70
                  ? const SizedBox.shrink() : Text(items[i].name, overflow: TextOverflow.ellipsis,
                    style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold)))))])),
          const SizedBox(height: 7), Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [const Text('00:00', style: TextStyle(color: UiColors.muted, fontSize: 11)),
              Text(timecode(Duration(milliseconds: totalMs ~/ 2)), style: const TextStyle(color: UiColors.muted, fontSize: 11)),
              Text(timecode(Duration(milliseconds: totalMs)), style: const TextStyle(color: UiColors.muted, fontSize: 11))]),
        ])), const SizedBox(height: 22),
      Row(children: [const Text('播放队列', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
        const Spacer(), const Text('拖动右侧手柄排序', style: TextStyle(color: UiColors.muted))]),
      const SizedBox(height: 12),
      Expanded(child: ReorderableListView.builder(buildDefaultDragHandles: false,
        itemCount: items.length, onReorder: (oldIndex, newIndex) => setState(() {
          if (newIndex > oldIndex) newIndex--;
          final moved = playlistIds.removeAt(oldIndex);
          playlistIds.insert(newIndex, moved);
        }), itemBuilder: (context, i) => Container(key: ValueKey(items[i].id),
          margin: const EdgeInsets.only(bottom: 10), padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          decoration: BoxDecoration(color: UiColors.surface, borderRadius: BorderRadius.circular(12)),
          child: Row(children: [CircleAvatar(radius: 15, backgroundColor: UiColors.elevated,
            child: Text('${i + 1}', style: const TextStyle(fontSize: 12))),
            const SizedBox(width: 14), Container(width: 5, height: 44,
              decoration: BoxDecoration(color: colors[i % colors.length], borderRadius: BorderRadius.circular(5))),
            const SizedBox(width: 14), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(items[i].name, style: const TextStyle(fontWeight: FontWeight.w600)),
              Text('${items[i].source} · ${timecode(items[i].start)} — ${timecode(items[i].end)}',
                style: const TextStyle(color: UiColors.muted, fontSize: 12), overflow: TextOverflow.ellipsis)])),
            Text(timecode(items[i].duration), style: const TextStyle(color: UiColors.muted)),
            const SizedBox(width: 12), ReorderableDragStartListener(index: i,
              child: const Icon(Icons.drag_handle, color: UiColors.muted))])))),
      const SizedBox(height: 8), Row(children: [const Icon(Icons.info_outline, size: 16, color: UiColors.muted),
        const SizedBox(width: 7), const Expanded(child: Text('演示模式：拖拽立即生效；接入实际项目时建议使用编辑副本 + 保存 / 重置。',
          style: TextStyle(fontSize: 12, color: UiColors.muted)))]),
    ]));
  }
}
