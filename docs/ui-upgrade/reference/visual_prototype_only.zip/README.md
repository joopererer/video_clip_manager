# Video Clip Manager — Dark Workspace UI Prototype

独立 Flutter Material 3 桌面 UI 原型。包含片段库、片段编辑器、播放列表，以及原始视频占位页面。

## 运行

在已安装 Flutter 3.32.8（或兼容的 Flutter 3.x）和 Windows 桌面编译环境的电脑上：

```bash
flutter create --platforms=windows .
flutter pub get
flutter run -d windows
```

如果直接覆盖现有工程，请**只将 lib/main.dart 中的代码作为参考**，不要覆盖原项目的应用入口或数据模型。这个包是独立演示工程，运行后使用内存样本数据，不访问磁盘视频、JSON 或 media_kit。

## 实现内容

- 深色主题和统一颜色 token
- Windows 宽屏左侧导航及窄屏折叠侧栏
- 片段库：文本搜索、收藏筛选、排序、列表/网格、评分与收藏
- 片段编辑器：媒体播放器占位、基础标签字段、RangeSlider 时间段演示（示范为秒级滑块，数据 Duration 精确到毫秒）
- 播放列表：按时长比例的概览时间轴、拖动改变播放顺序

## 未实现（应接入现有项目）

- Media Kit 实际播放/seek、截图和缩略图
- AppState/Provider 的实体更新、JSON 保存/加载、撤销/恢复
- 帧精准度、键盘 I/O 标记、可缩放精确时间轴
- 播放列表实际播放、跨片段跳转和音量控制
- 标签智能色彩、复杂多维筛选、批量操作

## 推荐正式目录

```
lib/
  design_system/{vcm_theme,vcm_spacing,vcm_typography}.dart
  shared/widgets/{media_thumbnail,timecode_field,section_header}.dart
  features/library/{clip_library_screen,widgets/clip_card}.dart
  features/editor/{clip_editor_screen,widgets/clip_range_timeline}.dart
  features/playlists/{playlist_workspace_screen,widgets/playlist_timeline}.dart
  services/  # 保留现有 Player / ScreenshotService / PathService
  state/     # 保留现有 Provider / AppState
```

## 数据接入建议

1. 将 DemoClip 替换成现有 Clip 模型/Adapter；软截取时间依旧是视频源相对时间。
2. 把示例 `setState` 的 favorite/rating 操作委托给现有 `AppState` 更新函数；不要重复创建存储。
3. 将 `fakeThumbnail` 替换为 ThumbnailService 的缩略图读取；缺失文件使用安全占位。
4. 将黑色播放器区域替换为你已有的 Media Kit 播放组件，**不要在 build() 中创建新 Player**。
5. 编辑器维护独立草稿（title/tags/start/end），点保存才提交，点取消放弃；当前原型直接修改内存实体仅为演示。
6. 播放列表维护编辑副本、undo/redo 栈，重排后再由用户主动保存；保存时复用项目既有事务逻辑。
7. 给 RangeSlider 升级为支持时间码输入/键盘逐帧步进的编辑器，校验 `0 <= start < end <= sourceDuration`。
8. 使用 ScaffoldMessenger / 现有 logger 反馈 Media Kit 异步操作异常。

## 设计取舍

浅色/深色主题不应改变模型及播放器生命周期。此原型没有引入第三方依赖，不会对已有 Media Kit 稳定性造成额外影响。
